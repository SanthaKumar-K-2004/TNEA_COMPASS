from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from pathlib import Path
import sqlite3, csv, json, urllib.request, urllib.error

ROOT=Path(__file__).resolve().parent
DB=ROOT/'tnlea.db'
DATA=ROOT/'data'
app=FastAPI(title='TNLEA Compass API',version='1.0.0',description='Evidence-labelled Tamil Nadu lateral-entry admissions research API')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['GET','POST'],allow_headers=['*'])
TABLES={'colleges':'TNLEA_Colleges.csv','branches':'TNLEA_College_Branches.csv','cutoffs':'TNLEA_Historical_Admissions.csv','sources':'TNLEA_Source_Register.csv','fees':'TNLEA_Fee_Records.csv'}

def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
 c=conn()
 for table,file in TABLES.items():
  p=DATA/file
  if not p.exists(): continue
  with p.open(encoding='utf-8-sig',newline='') as f:
   reader=csv.DictReader(f); cols=reader.fieldnames or []
   safe_cols=[x.replace(' ','_') for x in cols]
   c.execute(f'DROP TABLE IF EXISTS {table}')
   c.execute(f'CREATE TABLE {table} (id INTEGER PRIMARY KEY AUTOINCREMENT, '+','.join('"'+x+'" TEXT' for x in safe_cols)+')')
   rows=[]
   for row in reader: rows.append([row.get(x,'') for x in cols])
   if rows: c.executemany(f'INSERT INTO {table} ('+','.join('"'+x+'"' for x in safe_cols)+') VALUES ('+','.join('?' for _ in safe_cols)+')',rows)
  c.execute(f'CREATE INDEX IF NOT EXISTS idx_{table}_id ON {table}(id)')
 c.commit(); c.close()

@app.on_event('startup')
def startup(): init_db()

@app.get('/')
def home(): return FileResponse(ROOT/'app'/'index.html')
@app.get('/api/health')
def health():
 c=conn(); counts={t:c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in TABLES if c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",(t,)).fetchone()}; c.close()
 return {'status':'ok','version':app.version,'database':'sqlite','records':counts,'data_note':'Coverage is limited to the supplied research files; see /api/quality.'}
@app.get('/api/summary')
def summary():
 c=conn(); out={t:c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in TABLES}; c.close(); return out
@app.get('/api/quality')
def quality():
 return {'status':'limited_research_dataset','cutoff_years_available':[2024,2025],'cutoff_rows_in_supplied_csv':_count('cutoffs'),'limitations':['2023 source coverage is partial/unverified in this package','2024/2025 records reflect supplied extract and are not claimed exhaustive statewide coverage','No verified 2026 final cutoff dataset','Historical MIN/MAX fields are published marks, not ranks','Fee records are sparse; missing values are unknown, not zero','No verified statewide placement or sanctioned-seat coverage'],'forecasting':'No production ML forecast is exposed. Historical comparisons are descriptive only.'}
def _count(table):
 c=conn(); n=c.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]; c.close(); return n
@app.get('/api/colleges')
def colleges(q:str='',district:str='',limit:int=100,offset:int=0):
 limit=max(1,min(limit,500)); c=conn(); sql='SELECT * FROM colleges WHERE 1=1'; args=[]
 if q: sql+=' AND (official_name LIKE ? OR former_name LIKE ? OR tnlea_college_code LIKE ?)'; args += [f'%{q}%']*3
 if district: sql+=' AND district LIKE ?'; args.append(f'%{district}%')
 sql+=' ORDER BY official_name LIMIT ? OFFSET ?'; args += [limit,offset]
 rows=[dict(r) for r in c.execute(sql,args)]; c.close(); return {'items':rows,'limit':limit,'offset':offset}
@app.get('/api/cutoffs')
def cutoffs(college_code:str='',branch_code:str='',category:str='',year:int|None=None,limit:int=200):
 limit=max(1,min(limit,1000)); c=conn(); sql='SELECT * FROM cutoffs WHERE 1=1'; args=[]
 for col,val in [('college_code',college_code),('branch_code',branch_code),('reservation_category',category),('admission_year',str(year) if year else '')]:
  if val: sql+=f' AND "{col}"=?'; args.append(val)
 sql+=' ORDER BY admission_year DESC LIMIT ?'; args.append(limit); rows=[dict(r) for r in c.execute(sql,args)]; c.close(); return {'items':rows,'count':len(rows),'metric_note':'Published cutoff marks; do not interpret as rank.'}
@app.get('/api/sources')
def sources(limit:int=200):
 c=conn(); rows=[dict(r) for r in c.execute('SELECT * FROM sources LIMIT ?', (max(1,min(limit,500)),))]; c.close(); return {'items':rows}
class VacancyRequest(BaseModel): collegeCode:str=Field(min_length=1,max_length=12)
@app.post('/api/live/vacancy')
def live_vacancy(body:VacancyRequest):
 payload=json.dumps({'collegeCode':body.collegeCode}).encode(); req=urllib.request.Request('https://www.tnlea.com/api/user/vacancy-position',data=payload,headers={'Content-Type':'application/json','User-Agent':'TNLEA-Compass/1.0'},method='POST')
 try:
  with urllib.request.urlopen(req,timeout=12) as res: data=json.loads(res.read().decode())
 except (urllib.error.URLError,TimeoutError,ValueError) as e: raise HTTPException(status_code=502,detail=f'Official TNLEA vacancy source unavailable: {type(e).__name__}')
 return {'source':'TNLEA official vacancy-position API','college_code':body.collegeCode,'data':data,'interpretation':'Official published vacancy-position response. Not sanctioned intake or guaranteed currently available seats.'}
@app.get('/api/live/sources')
def live_sources(): return {'source':'https://www.tnlea.com/','checked_on_request':True,'note':'This endpoint identifies the official portal; it does not claim a background freshness monitor.'}
