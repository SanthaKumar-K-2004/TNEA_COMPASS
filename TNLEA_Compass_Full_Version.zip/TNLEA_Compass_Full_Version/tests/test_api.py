import unittest
import server

class PackageSmokeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): server.init_db()
    def test_database_counts(self):
        c=server.conn()
        self.assertGreater(c.execute('select count(*) from colleges').fetchone()[0],0)
        self.assertGreater(c.execute('select count(*) from cutoffs').fetchone()[0],0)
        c.close()
    def test_cutoff_metric_fields(self):
        c=server.conn(); cols={r[1] for r in c.execute('pragma table_info(cutoffs)')}; c.close()
        self.assertIn('min_cutoff_numeric',cols); self.assertIn('max_cutoff_numeric',cols)
    def test_data_quality_discloses_limitations(self):
        q=server.quality(); self.assertIn('No verified 2026 final cutoff dataset',q['limitations'])

if __name__=='__main__': unittest.main()
