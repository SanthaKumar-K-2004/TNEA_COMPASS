# TNLEA Compass — Full-stack starter package

This ZIP assembles the uploaded TNLEA Compass Premium dashboard and supplied research CSVs with a Python FastAPI + SQLite API, Dockerfile, Render blueprint and smoke tests. It is a newly assembled deployable package; it is **not** a recovered copy of the earlier v1.4.1 backend archive.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn server:app --reload
```
Open http://127.0.0.1:8000 and API docs at http://127.0.0.1:8000/docs. SQLite is created from `data/*.csv` on startup.

## API
- `GET /api/health`, `/api/summary`, `/api/quality`
- `GET /api/colleges?q=&district=&limit=&offset=`
- `GET /api/cutoffs?college_code=&branch_code=&category=&year=&limit=`
- `GET /api/sources`
- `POST /api/live/vacancy` JSON: `{"collegeCode":"2602"}` (proxies the official TNLEA vacancy-position endpoint)
- `GET /api/live/sources`

## Deploy

Recommended first deployment: **Render** using the included `render.yaml` / Dockerfile. Import the GitHub repository, choose Blueprint, and deploy. This Python API + SQLite package is not a static-only Vercel deployment. SQLite on ephemeral hosting is rebuilt from the bundled CSV files at startup; do not rely on runtime writes persisting. For durable user-generated data, migrate to managed PostgreSQL before adding write workflows.

## Data integrity / limitations

- Historical source values are preserved as text. Published `MIN`/`MAX` cutoff metrics are marks, not ranks.
- Supplied research files do not establish exhaustive statewide coverage. 2023 coverage is partial/unverified; 2024/2025 supplied extracts must not be called exhaustive; no verified 2026 final cutoff dataset is included.
- Fee records are sparse. Missing values mean unknown, not zero.
- The package does not claim a trained or validated ML forecast, guaranteed admission prediction, statewide placement database, or complete sanctioned-seat inventory.
- Live vacancy responses are official portal responses at request time, subject to portal availability. Vacancy-position data are not sanctioned intake or a promise of available seats.
- The Premium HTML is preserved as supplied. It is a standalone research dashboard and is not yet wired to every new API endpoint; API functionality is available independently at `/docs`.

## Checks

```bash
python -m unittest discover -s tests -v
```
