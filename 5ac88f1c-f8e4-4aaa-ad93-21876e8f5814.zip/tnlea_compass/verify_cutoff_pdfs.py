#!/usr/bin/env python3
"""Rebuild cutoff observations from official TNLEA PDFs with page-level provenance."""
import csv, hashlib, re, sqlite3, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).parent; DB=ROOT/'tnlea.db'; DATA=ROOT/'data'
SOURCES={
 2024: (ROOT.parent/'tnlea_source/extracted_docs/originals/tnlea/2024/cutoff_previous_year_2024.pdf','https://www.tnlea.com/QuickLinks/LEA-2025/Previous%20Year%20(2024)%20cutoff%20-%20LEA%202025.pdf'),
 2025: (ROOT.parent/'tnlea_source/extracted_docs/originals/tnlea/2025/cutoff_previous_year_2025.pdf','https://www.tnlea.com/QuickLinks/LEA-2026/Previous_Year_cutoff2025.pdf')}
CATS=['OC','BCM','BC','MBC','SC','SCA','ST']
PAT=re.compile(r'^\s*(\d{1,4})\s+(.*?)\s+([A-Z]{2})\s+((?:-|\d+(?:\.\d+)?)(?:\s+(?:-|\d+(?:\.\d+)?)){13})\s*$')
def main():
 db=sqlite3.connect(DB); db.row_factory=sqlite3.Row
 # Idempotent rebuild: replace the two supported years as one transaction.
 db.execute('DELETE FROM cutoff_observations WHERE admission_year IN (2024,2025)')
 names={r[0]:r[1] for r in db.execute('SELECT college_code,official_name FROM colleges')}
 with open(DATA/'cutoffs_2024_raw.csv',encoding='utf-8-sig') as f:
  for r in csv.DictReader(f): names.setdefault(r['college_code'],r['college_name_raw'])
 db.execute('ALTER TABLE cutoff_observations ADD COLUMN source_page INTEGER') if 'source_page' not in [x[1] for x in db.execute('pragma table_info(cutoff_observations)')] else None
 db.execute('ALTER TABLE cutoff_observations ADD COLUMN source_line INTEGER') if 'source_line' not in [x[1] for x in db.execute('pragma table_info(cutoff_observations)')] else None
 db.execute('ALTER TABLE cutoff_observations ADD COLUMN source_sha256 TEXT') if 'source_sha256' not in [x[1] for x in db.execute('pragma table_info(cutoff_observations)')] else None
 for year,(pdf,url) in SOURCES.items():
  if not pdf.exists(): raise SystemExit(f'Missing official source PDF: {pdf}')
  raw=subprocess.check_output(['pdftotext','-layout',str(pdf),'-'])
  txt=raw.decode('utf-8',errors='replace'); pages=txt.split('\f'); digest=hashlib.sha256(pdf.read_bytes()).hexdigest()
  header=' '.join(pages[0].splitlines()[:8])
  if not all(cat in header for cat in CATS):
   db.rollback(); raise SystemExit(f'{year}: expected community header labels not found; refusing positional category mapping')
  page_counts=[]; rejects=[]; parsed_keys=set()
  for page_no,page in enumerate(pages,1):
   count=0
   for line_no,line in enumerate(page.splitlines(),1):
    m=PAT.match(line)
    if not m: continue
    code,inline_name,branch,vals=m.groups(); vals=vals.split()
    key=(code,branch)
    if key in parsed_keys: db.rollback(); raise SystemExit(f'{year}: duplicate source college/branch row {key} at page {page_no}, line {line_no}')
    parsed_keys.add(key)
    if len(vals)!=14: rejects.append((page_no,line_no,line)); continue
    # Source PDF repeats college names in the text block; retain existing canonical name by code where present.
    name=names.get(code) or inline_name.strip() or f'College code {code}'
    for idx,cat in enumerate(CATS):
     mx,mn=vals[idx*2:idx*2+2]
     def num(v): return None if v=='-' else float(v)
     db.execute('''INSERT INTO cutoff_observations(admission_year,college_code,college_name,branch_code,category,max_mark,min_mark,max_raw,min_raw,source_url,source_file,verification_status,rank_status,source_page,source_line,source_sha256)
       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(year,code,name,branch,cat,num(mx),num(mn),mx,mn,url,pdf.name,'official_pdf_extracted_structure_qa_pass_spot_check_pending','Not published; values are cutoff marks',page_no,line_no,digest))
    count+=1
   page_counts.append(count)
   if count==0 and page_no<=len(pages)-1: pass
  # Only replace after parse has completed and passed structural checks.
  expected=2248 if year==2025 else 2140
  if sum(page_counts)!=expected:
   db.rollback(); raise SystemExit(f'{year}: branch-row count mismatch {sum(page_counts)} != expected QA baseline {expected}')
  db.execute("UPDATE data_sources SET status=?,notes=? WHERE year=?",('source_pdf_extracted_structure_qa_pass_spot_check_pending',f'Official PDF SHA-256 {digest}; {len(pages)-1} pages; {sum(page_counts)} branch rows; {sum(page_counts)*7} category observations; 14 numeric/dash cells validated per row. Page-level provenance stored. Human visual spot checks still pending.',str(year)))
  print(f'{year}: pages={len(pages)-1}, branch_rows={sum(page_counts)}, observations={sum(page_counts)*7}, colleges={len(set(r[0] for r in db.execute("select college_code from cutoff_observations where admission_year=?",(year,))))}, sha256={digest}')
  print(f'  first page rows={page_counts[:5]}, last page rows={page_counts[-5:]}')
  if rejects: print('  rejected lines',len(rejects))
 db.commit()
 # Data integrity checks
 for y in SOURCES:
  x=db.execute('''select count(*) n,count(distinct college_code||'|'||branch_code) branches,
   sum(case when min_mark>max_mark then 1 else 0 end) invalid_pairs,
   sum(case when max_mark is not null then 1 else 0 end) max_present,
   sum(case when min_mark is not null then 1 else 0 end) min_present
   from cutoff_observations where admission_year=?''',(y,)).fetchone()
  print('QA',y,dict(x))
 db.close()
if __name__=='__main__': main()
