# TNLEA Compass v1.2 — cutoff data verification report

## Scope
Official TNLEA previous-year cutoff PDFs for admission years 2024 and 2025 were downloaded from TNLEA URLs and re-parsed using layout-preserving PDF text extraction. Every parsed branch row must contain a college code, two-letter branch code, and exactly 14 MAX/MIN cells (7 communities × 2 values). Dashes are preserved as unpublished values, not converted to zero.

## Results
| Admission year | PDF pages | Branch rows parsed | Community observations | College codes | Branch codes | Invalid MIN > MAX pairs |
|---|---:|---:|---:|---:|---:|---:|
| 2024 | 142 | 2,140 | 14,980 | 417 | 90 | 0 |
| 2025 | 144 | 2,248 | 15,736 | 410 | 95 | 0 |

Each observation stores the official source URL, PDF filename, SHA-256 digest, source page, source text line, and extraction status. The CSV `data/cutoff_extraction_audit.csv` records the reproducible summary.

## Verification boundary
- Structural extraction QA passed: expected branch-row counts, 14-cell row shape, category expansion, unique-key integrity and MAX/MIN sanity checks.
- This is **not** a manual visual verification of every cell in the source PDFs. Status remains `official_pdf_extracted_structure_qa_pass_spot_check_pending`.
- Six 2024 college codes are absent from the current official 2025 directory; names are retained from the earlier 2024 extraction, and must not be treated as a current-year directory membership assertion.
- 2022 and 2023 cutoff data are not loaded. 2026 final cutoff is not verified; a vacancy list is not a final cutoff.
- College fees, hostel/mess costs, branch-wise placements, scholarships and institution ranking rows remain unverified and empty.
- MIN/MAX are cutoff marks, not opening/closing ranks. Recommendation output is historical compatibility screening only, not an admission chance or seat guarantee.

## Rebuild
Run `python3 verify_cutoff_pdfs.py` from this directory. It downloads nothing: the original source PDFs are included in the project archive under `../tnlea_source/extracted_docs/originals/tnlea/`. The script rebuilds 2024/2025 observations idempotently from those local PDFs.

## v1.3 quality hardening
- API rejects invalid marks (including NaN/Infinity), unsupported community codes, unsupported years, malformed compare codes and invalid pagination values.
- Cutoff and college directory endpoints now return total counts and paginated slices instead of silently truncating results.
- Recommendation output is ordered by absolute difference from the published historical MIN mark; it no longer uses an arbitrary 5-point band or implies admission likelihood.
- College comparison includes cutoff evidence and flags duplicate college codes as ambiguous.
- Automated regression suite: 6 database checks covering SQLite integrity, duplicate cutoff grain, numeric bounds, source provenance, year scope and absence of unverified financial/placement/ranking/scholarship/seat rows.

## v1.4 live official data
- Live source queried: `https://www.tnlea.com/api/user/vacancy-position` (public endpoint invoked by the official TNLEA `/vacancy-position` page).
- Request shape confirmed from the official portal frontend bundle: POST JSON `{"collegeCode":"..."}`. The portal page labels the data “VACANCY POSITION AFTER ROUND 1”.
- A live request on 2026-10-31 for college code 2602 returned 8 branch records, all with non-zero category counters. The CS row returned OC 9, BC 8, BCM 1, MBC 6, SC 4, SCA 1, ST 0, COUNTER 29. These are a time-stamped source snapshot, not a claim of seats currently open.
- A live request for college code 1 returned 18 branch rows, all with zero counts. The UI must preserve those zeroes as source values and must not infer that the programmes do not exist.
- Five official TNLEA URLs returned HTTP 200 on 2026-10-31: homepage, 2026 candidate instructions, vacancy page, 2025 previous cutoff PDF and 2025 college directory PDF. Last-Modified and ETag are stored for change detection.
- Live vacancy responses are checked for branch identity, seven non-negative integer category values and `COUNTER = OC + BC + BCM + MBC + SC + SCA + ST`; raw payloads, retrieval timestamp, source URL and SHA-256 are stored.
- No live 2026 vacancy data is added to historical cutoff observations. The source itself is specifically “after Round 1”; it is not a real-time allotment stream, sanctioned intake, or guaranteed currently available seat count.
- API tests on 2026-10-31: valid live fetch, source monitor, snapshot history, malformed code rejection and non-existent code upstream 404 handling passed.

## Free-runtime and delivery audit (31 October 2026)
- Runtime dependencies: Python standard library only; `requirements.txt` contains no installable package requirements.
- Chart.js 4.4.7 is locally bundled in `app/vendor/chart.umd.min.js`; license is included in `app/vendor/CHARTJS-LICENSE.txt`. The browser no longer needs jsDelivr for chart rendering.
- Server now serves the local vendor asset, uses a threaded HTTP server and binds to `127.0.0.1` by default. Set `HOST=0.0.0.0` only for trusted LAN use. Wildcard CORS was removed because the UI and API are same-origin.
- Static asset route path traversal test returned 404.
- Remaining external dependency is the official TNLEA website for live vacancy and source checks; those features correctly require internet access.
- Automated tests: 10/10 pass; Python compilation and inline JavaScript syntax checks pass. Browser interaction testing remains pending until Chromium installation completes.

## v1.4.1 free-runtime verification
- Chart.js 4.4.7 was downloaded and bundled locally; runtime CDN reference removed. Local vendor asset route responds HTTP 200 and the bundled license file is available.
- Default server bind changed to loopback (`127.0.0.1`); wildcard CORS removed; static vendor path traversal probe rejected with HTTP 404. Threaded HTTP server used for concurrent requests.
- No paid API keys, external AI providers, paid databases, or non-standard Python packages are required for the core application. Internet access is still required for live TNLEA data.
- 15 automated tests passed; Python compilation, inline JavaScript syntax, 16 route/static asset smoke checks and invalid-input rejection checks passed.
- Browser-level visual/interaction test is not certified: Chromium download did not complete in the sandbox. Do not treat HTTP and syntax checks as a substitute for a real mobile/desktop browser acceptance test.
