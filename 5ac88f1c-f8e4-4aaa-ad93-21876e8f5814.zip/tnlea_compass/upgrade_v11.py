import sqlite3,os,csv
R=os.path.dirname(__file__); db=sqlite3.connect(os.path.join(R,'tnlea.db'))
db.executescript('''
CREATE TABLE IF NOT EXISTS college_fees(id INTEGER PRIMARY KEY,college_code TEXT,academic_year TEXT,course TEXT,tuition_fee REAL,other_mandatory_fee REAL,hostel_fee REAL,mess_fee REAL,transport_fee REAL,scholarship_notes TEXT,source_url TEXT,verification_status TEXT DEFAULT 'not_verified');
CREATE TABLE IF NOT EXISTS placement_outcomes(id INTEGER PRIMARY KEY,college_code TEXT,academic_year TEXT,branch_code TEXT,students_eligible INTEGER,students_placed INTEGER,placement_rate REAL,median_salary_lpa REAL,average_salary_lpa REAL,highest_salary_lpa REAL,recruiters TEXT,source_url TEXT,verification_status TEXT DEFAULT 'not_verified');
CREATE TABLE IF NOT EXISTS institutional_rankings(id INTEGER PRIMARY KEY,college_code TEXT,ranking_system TEXT,rank_year INTEGER,category TEXT,rank_position INTEGER,score REAL,source_url TEXT,verification_status TEXT DEFAULT 'not_verified');
CREATE TABLE IF NOT EXISTS scholarships(id INTEGER PRIMARY KEY,college_code TEXT,scheme_name TEXT,eligibility TEXT,benefit_amount REAL,academic_year TEXT,source_url TEXT,verification_status TEXT DEFAULT 'not_verified');
CREATE TABLE IF NOT EXISTS branch_seats(id INTEGER PRIMARY KEY,college_code TEXT,academic_year TEXT,branch_code TEXT,sanctioned_intake INTEGER,available_seats INTEGER,source_url TEXT,verification_status TEXT DEFAULT 'not_verified');
CREATE INDEX IF NOT EXISTS idx_fee_college ON college_fees(college_code,academic_year);
CREATE INDEX IF NOT EXISTS idx_place_college ON placement_outcomes(college_code,academic_year,branch_code);
''')
db.commit();db.close()
# CSV templates only: intentionally empty except headers.
templates={
'college_fees_template.csv':['college_code','academic_year','course','tuition_fee_inr','other_mandatory_fee_inr','hostel_fee_inr','mess_fee_inr','transport_fee_inr','scholarship_notes','source_url','verification_status'],
'placement_outcomes_template.csv':['college_code','academic_year','branch_code','students_eligible','students_placed','placement_rate_percent','median_salary_lpa','average_salary_lpa','highest_salary_lpa','recruiters','source_url','verification_status'],
'institutional_rankings_template.csv':['college_code','ranking_system','rank_year','category','rank_position','score','source_url','verification_status'],
'scholarships_template.csv':['college_code','scheme_name','eligibility','benefit_amount_inr','academic_year','source_url','verification_status'],
'branch_seats_template.csv':['college_code','academic_year','branch_code','sanctioned_intake','available_seats','source_url','verification_status']}
for fn,cols in templates.items():
 with open(os.path.join(R,'data',fn),'w',newline='') as f:csv.writer(f).writerow(cols)
print('schema upgraded; five import templates generated')
