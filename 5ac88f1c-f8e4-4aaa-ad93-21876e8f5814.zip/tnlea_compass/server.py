from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs
import sqlite3,json,os,mimetypes,math,urllib.request,urllib.error,hashlib,datetime,time
ROOT=os.path.dirname(__file__); DB=os.path.join(ROOT,'tnlea.db')
TNLEA='https://www.tnlea.com'
LIVE_SOURCES=[
 {'key':'tnlea_home','title':'TNLEA official 2026 portal','url':TNLEA+'/'},
 {'key':'tnlea_2026_instructions','title':'TNLEA 2026-27 candidate instructions','url':TNLEA+'/QuickLinks/LEA-2026/General%20Information%20to%20Candidates%20%28English%29-%20LEA%202026.pdf'},
 {'key':'tnlea_vacancy_api','title':'TNLEA official vacancy-after-Round-1 data service','url':TNLEA+'/vacancy-position'},
 {'key':'tnlea_2025_cutoff','title':'TNLEA previous-year 2025 cutoff PDF','url':TNLEA+'/QuickLinks/LEA-2026/Previous_Year_cutoff2025.pdf'},
 {'key':'tnlea_2025_directory','title':'TNLEA official 2025 college directory','url':TNLEA+'/QuickLinks/LEA-2025/listofcollegs.pdf'}]
def utcnow(): return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
def init_live_tables():
 c=sqlite3.connect(DB)
 c.executescript('''CREATE TABLE IF NOT EXISTS live_source_checks(id INTEGER PRIMARY KEY,source_key TEXT NOT NULL,title TEXT NOT NULL,url TEXT NOT NULL,checked_at TEXT NOT NULL,http_status INTEGER,reachable INTEGER NOT NULL,last_modified TEXT,etag TEXT,content_type TEXT,content_length INTEGER,error TEXT); CREATE INDEX IF NOT EXISTS idx_live_source_key ON live_source_checks(source_key,checked_at); CREATE TABLE IF NOT EXISTS live_vacancy_snapshots(id INTEGER PRIMARY KEY,college_code TEXT NOT NULL,institution_name TEXT NOT NULL,retrieved_at TEXT NOT NULL,source_url TEXT NOT NULL,record_count INTEGER NOT NULL,nonzero_branch_count INTEGER NOT NULL,payload_sha256 TEXT NOT NULL,payload_json TEXT NOT NULL); CREATE INDEX IF NOT EXISTS idx_vacancy_code_time ON live_vacancy_snapshots(college_code,retrieved_at);''')
 c.commit();c.close()
def fetch_live_vacancy(code):
 payload=json.dumps({'collegeCode':code}).encode()
 req=urllib.request.Request(TNLEA+'/api/user/vacancy-position',data=payload,method='POST',headers={'Content-Type':'application/json','Accept':'application/json','User-Agent':'TNLEA-Compass-Student-Research/1.0','Origin':TNLEA,'Referer':TNLEA+'/vacancy-position'})
 with urllib.request.urlopen(req,timeout=20) as resp:
  if resp.status!=200: raise RuntimeError('TNLEA returned HTTP '+str(resp.status))
  raw=resp.read(2_000_000)
  if len(raw)>=2_000_000: raise RuntimeError('Response exceeded safety limit')
  data=json.loads(raw.decode('utf-8'))
 rows=data.get('vacancyDetails')
 if not isinstance(rows,list) or not rows: raise ValueError('Official portal returned no vacancy rows for this college code')
 cats=('OC','BC','BCM','MBC','SC','SCA','ST')
 for row in rows:
  if str(row.get('COLL_CODE'))!=code or not row.get('BRANCH'): raise ValueError('Unexpected college/branch structure in upstream response')
  for cat in cats:
   v=row.get(cat)
   if not isinstance(v,int) or v<0: raise ValueError('Unexpected category count in upstream response')
  if int(row.get('COUNTER',-1))!=sum(row[k] for k in cats): raise ValueError('Upstream COUNTER does not reconcile to category totals')
 name=str(rows[0].get('INSTITUTION','')).strip()
 if any(str(x.get('INSTITUTION','')).strip()!=name for x in rows): raise ValueError('Inconsistent institution name across branch rows')
 stamp=utcnow(); rawjson=json.dumps(rows,ensure_ascii=False,separators=(',',':')); digest=hashlib.sha256(rawjson.encode()).hexdigest()
 nonzero=sum(1 for x in rows if x['COUNTER']>0)
 c=sqlite3.connect(DB);c.row_factory=sqlite3.Row
 previous=c.execute('select retrieved_at,payload_json from live_vacancy_snapshots where college_code=? order by id desc limit 1',(code,)).fetchone()
 changes=[]; previous_at=None
 if previous:
  previous_at=previous['retrieved_at']; old={x['BRANCH']:x for x in json.loads(previous['payload_json'])}
  for current in rows:
   prior=old.get(current['BRANCH'])
   if prior:
    for cat in cats:
     delta=current[cat]-prior[cat]
     if delta: changes.append({'branch':current['BRANCH'],'category':cat,'previous':prior[cat],'current':current[cat],'delta':delta})
 c.execute('insert into live_vacancy_snapshots(college_code,institution_name,retrieved_at,source_url,record_count,nonzero_branch_count,payload_sha256,payload_json) values(?,?,?,?,?,?,?,?)',(code,name,stamp,TNLEA+'/vacancy-position',len(rows),nonzero,digest,rawjson));c.commit();c.close()
 return {'college_code':code,'institution_name':name,'retrieved_at':stamp,'previous_snapshot_at':previous_at,'changes_since_previous_fetch':changes,'source_url':TNLEA+'/vacancy-position','source_label':'Official TNLEA 2026 — Vacancy Position After Round 1','record_count':len(rows),'nonzero_branch_count':nonzero,'payload_sha256':digest,'rows':rows,'interpretation':'This is the portal’s published post-Round-1 vacancy snapshot, retrieved live. It is not a guarantee of seats currently available, a live allotment feed, or a sanctioned-intake figure.'}
init_live_tables()
def conn():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def send(h,obj,status=200):
 b=json.dumps(obj,ensure_ascii=False).encode(); h.send_response(status); h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Content-Length',str(len(b))); h.end_headers(); h.wfile.write(b)
class Handler(BaseHTTPRequestHandler):
 def do_POST(self):
  u=urlparse(self.path)
  try:
   length=int(self.headers.get('Content-Length','0'))
   if length<=0 or length>16384: return send(self,{'error':'Invalid request body size.'},400)
   body=json.loads(self.rfile.read(length).decode('utf-8'))
  except Exception: return send(self,{'error':'Request body must be valid JSON.'},400)
  if u.path=='/api/live/vacancy':
   code=str(body.get('collegeCode','')).strip()
   if not code.isdigit() or not 1<=len(code)<=4: return send(self,{'error':'Enter a valid TNLEA college code (1–4 digits).'},400)
   try: return send(self,fetch_live_vacancy(code))
   except urllib.error.HTTPError as e: return send(self,{'error':'Official TNLEA service returned HTTP '+str(e.code),'source_url':TNLEA+'/vacancy-position'},502)
   except Exception as e: return send(self,{'error':'Could not verify live data from the official TNLEA service: '+str(e),'source_url':TNLEA+'/vacancy-position'},502)
  if u.path=='/api/live/refresh-sources':
   results=[]; c=sqlite3.connect(DB)
   for src in LIVE_SOURCES:
    checked=utcnow(); status=None; reachable=0; lm=etag=ctype=None; size=None; err=None
    try:
     req=urllib.request.Request(src['url'],method='HEAD',headers={'User-Agent':'TNLEA-Compass-Source-Monitor/1.0','Accept':'*/*'})
     with urllib.request.urlopen(req,timeout=15) as resp:
      status=resp.status; reachable=1; lm=resp.headers.get('Last-Modified'); etag=resp.headers.get('ETag'); ctype=resp.headers.get('Content-Type'); size=int(resp.headers.get('Content-Length') or 0) or None
    except urllib.error.HTTPError as e: status=e.code; err='HTTP '+str(e.code)
    except Exception as e: err=str(e)[:300]
    c.execute('insert into live_source_checks(source_key,title,url,checked_at,http_status,reachable,last_modified,etag,content_type,content_length,error) values(?,?,?,?,?,?,?,?,?,?,?)',(src['key'],src['title'],src['url'],checked,status,reachable,lm,etag,ctype,size,err))
    previous=c.execute('select etag,last_modified from live_source_checks where source_key=? and id < last_insert_rowid() order by id desc limit 1',(src['key'],)).fetchone()
    changed=bool(previous and ((etag and previous[0] and etag!=previous[0]) or (lm and previous[1] and lm!=previous[1])))
    results.append({'key':src['key'],'title':src['title'],'url':src['url'],'checked_at':checked,'http_status':status,'reachable':bool(reachable),'last_modified':lm,'etag':etag,'content_type':ctype,'content_length':size,'changed_since_previous_check':changed,'error':err})
   c.commit();c.close()
   return send(self,{'checked_at':utcnow(),'items':results,'note':'This checks official source reachability and HTTP metadata (ETag/Last-Modified). It does not certify the content or imply that seats are currently open.'})
  return send(self,{'error':'not_found'},404)
 def do_GET(self):
  u=urlparse(self.path); q=parse_qs(u.query); c=conn()
  if u.path=='/api/health': return send(self,{'status':'ok','service':'TNLEA Compass API','database':'connected'})
  if u.path=='/api/live/sources':
   items=[]
   for src in LIVE_SOURCES:
    r=c.execute('select * from live_source_checks where source_key=? order by id desc limit 1',(src['key'],)).fetchone()
    items.append({'key':src['key'],'title':src['title'],'url':src['url'],'last_check':dict(r) if r else None})
   return send(self,{'items':items,'note':'Last saved reachability checks. Use Refresh official sources to make a new live request.'})
  if u.path=='/api/live/vacancy-history':
   code=q.get('college',[''])[0].strip()
   if not code.isdigit() or not 1<=len(code)<=4: return send(self,{'error':'Valid college code required.'},400)
   rows=[dict(x) for x in c.execute('select id,college_code,institution_name,retrieved_at,source_url,record_count,nonzero_branch_count,payload_sha256 from live_vacancy_snapshots where college_code=? order by id desc limit 10',(code,))]
   return send(self,{'items':rows})
  if u.path=='/api/quality':
   years=[]
   for y in (2024,2025):
    r=c.execute('''select count(*) observations,count(distinct college_code||'|'||branch_code) branch_rows,count(distinct college_code) colleges,count(distinct branch_code) branches,sum(case when max_mark is not null then 1 else 0 end) populated_pairs,sum(case when min_mark>max_mark then 1 else 0 end) invalid_pairs,count(distinct source_page) pages from cutoff_observations where admission_year=?''',(y,)).fetchone()
    expected={2024:2140,2025:2248}[y]
    bad=c.execute('''select count(*) from cutoff_observations where admission_year=? and (min_mark<0 or min_mark>100 or max_mark<0 or max_mark>100 or (min_mark is null)!=(max_mark is null) or source_url is null or source_page is null or source_line is null or source_sha256 is null)''',(y,)).fetchone()[0]
    cats=c.execute('select count(distinct category) from cutoff_observations where admission_year=?',(y,)).fetchone()[0]
    years.append({'year':y,**dict(r),'expected_branch_rows':expected,'branch_row_coverage_pct':round(100*r['branch_rows']/expected,2) if expected else 0,'categories':cats,'invalid_or_unprovenanced_rows':bad,'status':'STRUCTURE_QA_PASS' if r['branch_rows']==expected and r['observations']==expected*7 and r['invalid_pairs']==0 and bad==0 and cats==7 else 'REVIEW_REQUIRED'})
   return send(self,{'years':years,'other_data':{'fees_verified':c.execute("select count(*) from college_fees where verification_status='verified'").fetchone()[0],'placements_verified':c.execute("select count(*) from placement_outcomes where verification_status='verified'").fetchone()[0],'rankings_verified':c.execute("select count(*) from institutional_rankings where verification_status='verified'").fetchone()[0],'scholarships_verified':c.execute("select count(*) from scholarships where verification_status='verified'").fetchone()[0]},'note':'Structure checks validate PDF extraction shape and provenance, not manual visual verification of every cell.'})
  if u.path=='/api/summary':
   years=[dict(x) for x in c.execute('select admission_year,count(*) records,count(distinct college_code) colleges,count(distinct branch_code) branches from cutoff_observations group by admission_year order by admission_year')]
   return send(self,{'college_directory':c.execute('select count(*) from colleges').fetchone()[0],'cutoff_records':c.execute('select count(*) from cutoff_observations').fetchone()[0],'years':years,'sources':[dict(x) for x in c.execute('select year,status,count(*) as count from data_sources group by year,status order by year')],'prediction_status':'INSUFFICIENT_HISTORY','note':'Official 2024 and 2025 PDF tables have passed structural extraction QA with page-level provenance; manual visual spot checks and older-year recovery remain pending. Forecasting stays disabled until sufficient validated history and backtesting exist.'})
  if u.path=='/api/colleges':
   term=q.get('q',[''])[0].strip()
   try: limit=max(1,min(200,int(q.get('limit',['100'])[0]))); offset=max(0,int(q.get('offset',['0'])[0]))
   except ValueError: return send(self,{'error':'limit and offset must be integers.'},400)
   args=[]; where=''
   if term: where=' where college_code like ? or official_name like ? or district like ?'; args=[f'%{term}%']*3
   total=c.execute('select count(*) from colleges'+where,args).fetchone()[0]
   sql='select college_code,official_name,address,district,verification_status,duplicate_code_flag from colleges'+where+' order by official_name limit ? offset ?'
   items=[dict(x) for x in c.execute(sql,args+[limit,offset])]
   return send(self,{'items':items,'total':total,'limit':limit,'offset':offset,'has_more':offset+len(items)<total})
  if u.path=='/api/cutoffs':
   year=q.get('year',[''])[0]; category=q.get('category',[''])[0].upper(); college=q.get('college',[''])[0].strip(); branch=q.get('branch',[''])[0].strip().upper()
   if year and (not year.isdigit() or int(year)<2000 or int(year)>2100): return send(self,{'error':'Invalid admission year.'},400)
   if category and category not in {'OC','BC','BCM','MBC','SC','SCA','ST'}: return send(self,{'error':'Unsupported community category.'},400)
   try: limit=max(1,min(500,int(q.get('limit',['100'])[0]))); offset=max(0,int(q.get('offset',['0'])[0]))
   except ValueError: return send(self,{'error':'limit and offset must be integers.'},400)
   where=' where 1=1'; args=[]
   for val,col in [(year,'admission_year'),(category,'category'),(college,'college_code'),(branch,'branch_code')]:
    if val: where+=f' and {col}=?'; args.append(val)
   total=c.execute('select count(*) from cutoff_observations'+where,args).fetchone()[0]
   sql='select admission_year,college_code,college_name,branch_code,category,max_mark,min_mark,source_url,verification_status,rank_status,source_page,source_line,source_sha256 from cutoff_observations'+where+' order by admission_year desc,college_name,branch_code,category limit ? offset ?'
   items=[dict(x) for x in c.execute(sql,args+[limit,offset])]
   return send(self,{'items':items,'total':total,'limit':limit,'offset':offset,'has_more':offset+len(items)<total})
  if u.path=='/api/forecast':
   college=q.get('college',[''])[0]; branch=q.get('branch',[''])[0]; category=q.get('category',['OC'])[0]
   rows=[dict(x) for x in c.execute('select admission_year,min_mark,max_mark,source_url from cutoff_observations where college_code=? and branch_code=? and category=? and min_mark is not null order by admission_year',(college,branch,category))]
   years=sorted({r['admission_year'] for r in rows})
   if len(years)<3: return send(self,{'status':'insufficient_history','forecast':None,'observations':rows,'message':'At least three validated comparable admission years are required before a forecast is published. Current extracts are preliminary and cover only 2024–2025.'})
   return send(self,{'status':'needs_model_validation','forecast':None,'observations':rows,'message':'Historical observations are available; run chronological backtesting before publishing a forecast.'})
  if u.path=='/api/recommend':
   try: mark=float(q.get('mark',[''])[0])
   except (ValueError,TypeError): return send(self,{'error':'A valid cutoff mark between 0 and 100 is required.'},400)
   if not math.isfinite(mark) or not 0<=mark<=100: return send(self,{'error':'Cutoff mark must be a finite number between 0 and 100.'},400)
   cat=q.get('category',['OC'])[0].upper(); year=q.get('year',['2025'])[0]
   branch=q.get('branch',[''])[0].strip().upper(); college=q.get('college',[''])[0].strip()
   if cat not in {'OC','BC','BCM','MBC','SC','SCA','ST'}: return send(self,{'error':'Unsupported community category.'},400)
   if year not in {'2024','2025'}: return send(self,{'error':'No validated cutoff dataset is available for that year.'},400)
   sql="select college_code,college_name,branch_code,min_mark,max_mark,admission_year,source_url,source_page,source_line,verification_status from cutoff_observations where admission_year=? and category=? and min_mark is not null"
   args=[year,cat]
   if branch: sql+=' and branch_code=?'; args.append(branch)
   if college: sql+=' and college_code=?'; args.append(college)
   rows=[dict(x) for x in c.execute(sql,args)]
   for x in rows:
    gap=round(mark-x['min_mark'],4); x['gap']=gap
    x['historical_comparison']='at_or_above_published_minimum' if gap>=0 else 'below_published_minimum'
   # Show historical matches first, closest published minimum first; then near misses.
   rows.sort(key=lambda x:(0 if x['gap']>=0 else 1,abs(x['gap']),x['college_name'],x['branch_code']))
   return send(self,{'items':rows[:250],'total_matches':len(rows),'input_mark':mark,'category':cat,'year':int(year),'branch_filter':branch or None,'college_filter':college or None,'method':'Historical MIN cutoff comparison. At/above means only that the input mark meets or exceeds that published historical minimum; it does not estimate admission probability. Results are ordered by absolute mark difference.','warning':'Historical evidence only. Not a rank prediction, admission probability, current vacancy check or seat guarantee. Source page and line are included for each observation.'})
  if u.path=='/api/compare':
   codes=list(dict.fromkeys(x.strip() for x in q.get('codes',[''])[0].split(',') if x.strip()))
   if len(codes)>5: return send(self,{'error':'Compare up to five college codes.'},400)
   if any(len(x)>12 or not x.isalnum() for x in codes): return send(self,{'error':'Invalid college code.'},400)
   if not codes:return send(self,{'items':[]})
   marks=','.join('?' for _ in codes)
   colleges=[dict(x) for x in c.execute(f'select college_code,official_name,address,district,verification_status,duplicate_code_flag from colleges where college_code in ({marks})',codes)]
   ambiguous=[{'college_code':code,'records':sum(1 for row in colleges if row['college_code']==code)} for code in codes if sum(1 for row in colleges if row['college_code']==code)>1]
   fees=[dict(x) for x in c.execute(f'select * from college_fees where college_code in ({marks})',codes)]
   placements=[dict(x) for x in c.execute(f'select * from placement_outcomes where college_code in ({marks})',codes)]
   rankings=[dict(x) for x in c.execute(f'select * from institutional_rankings where college_code in ({marks})',codes)]
   cutoffs=[dict(x) for x in c.execute(f'select admission_year,college_code,college_name,branch_code,category,max_mark,min_mark,source_url,source_page,source_line,verification_status from cutoff_observations where college_code in ({marks}) order by admission_year desc,branch_code,category',codes)]
   return send(self,{'colleges':colleges,'ambiguous_college_codes':ambiguous,'cutoffs':cutoffs,'fees':fees,'placements':placements,'rankings':rankings,'note':'Historical cutoffs are shown with source references. Ambiguous directory codes must be disambiguated before treating them as a single college. Fee, placement and ranking data are not verified and are not populated.'})
  if u.path=='/api/sources': return send(self,{'items':[dict(x) for x in c.execute('select * from data_sources order by year')]})
  if u.path=='/':
   p=os.path.join(ROOT,'app','index.html'); b=open(p,'rb').read(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
  if u.path.startswith('/vendor/'):
   name=u.path[len('/vendor/'):]
   if not name or '/' in name or '\\' in name or name.startswith('.'): return send(self,{'error':'not_found'},404)
   p=os.path.realpath(os.path.join(ROOT,'app','vendor',name))
   if not p.startswith(os.path.realpath(os.path.join(ROOT,'app','vendor'))+os.sep) or not os.path.isfile(p): return send(self,{'error':'not_found'},404)
   b=open(p,'rb').read(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(p)[0] or 'application/octet-stream'); self.send_header('Cache-Control','public, max-age=86400'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
  return send(self,{'error':'not_found'},404)
 def log_message(self,*a): pass
if __name__=='__main__':
 port=int(os.getenv('PORT','8000')); host=os.getenv('HOST','127.0.0.1'); print(f'TNLEA Compass running at http://{host}:{port}'); ThreadingHTTPServer((host,port),Handler).serve_forever()
