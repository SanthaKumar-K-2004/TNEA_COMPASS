import sqlite3,csv,os,json
ROOT=os.path.dirname(__file__); DATA=os.path.join(ROOT,'data'); db=sqlite3.connect(os.path.join(ROOT,'tnlea.db'))
db.executescript('''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS colleges(id INTEGER PRIMARY KEY, college_code TEXT NOT NULL, official_name TEXT, address TEXT, district TEXT, source_url TEXT, verification_status TEXT, duplicate_code_flag INTEGER DEFAULT 0, UNIQUE(college_code,official_name));
CREATE TABLE IF NOT EXISTS cutoff_observations(id INTEGER PRIMARY KEY, admission_year INTEGER NOT NULL, college_code TEXT NOT NULL, college_name TEXT, branch_code TEXT NOT NULL, category TEXT NOT NULL, max_mark REAL, min_mark REAL, max_raw TEXT, min_raw TEXT, source_url TEXT, source_file TEXT, verification_status TEXT, rank_status TEXT, UNIQUE(admission_year,college_code,branch_code,category));
CREATE INDEX IF NOT EXISTS idx_cutoff_lookup ON cutoff_observations(admission_year,college_code,branch_code,category);
CREATE TABLE IF NOT EXISTS data_sources(id INTEGER PRIMARY KEY, title TEXT, year TEXT, url TEXT, status TEXT, notes TEXT);
''')
# Directory: preserve raw duplicate source records, but canonicalize on code + name.
with open(os.path.join(ROOT,'..','tnlea_source','extracted','TNLEA_Official_College_Directory_2025.csv'),encoding='utf-8-sig') as f:
 rows=list(csv.DictReader(f))
 seen=set()
 for r in rows:
  key=(r['college_code'].strip(),r['official_name'].strip())
  if key in seen: continue
  seen.add(key)
  db.execute('INSERT OR IGNORE INTO colleges(college_code,official_name,address,district,source_url,verification_status,duplicate_code_flag) VALUES(?,?,?,?,?,?,?)',(key[0],key[1],r.get('address_raw'),r.get('district_evidence'),r.get('source_url'),r.get('verification_status'),1 if str(r.get('duplicate_code_in_source')).lower()=='true' else 0))
# Cutoff extracts: import as preliminary until automated spot checks completed.
for year in (2024,2025):
 with open(os.path.join(DATA,f'cutoffs_{year}_raw.csv'),encoding='utf-8-sig') as f:
  for r in csv.DictReader(f):
   db.execute('INSERT OR IGNORE INTO cutoff_observations(admission_year,college_code,college_name,branch_code,category,max_mark,min_mark,max_raw,min_raw,source_url,source_file,verification_status,rank_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(int(r['admission_year']),r['college_code'],r['college_name_raw'],r['branch_code'],r['category'],float(r['published_max']) if r['published_max'] else None,float(r['published_min']) if r['published_min'] else None,r['published_max_raw'],r['published_min_raw'],r['source_url'],r['source_file'],r['verification_status'],r['rank_status']))
# Sources and honest coverage statuses.
sources=[('TNLEA 2024 previous-year cutoff','2024','https://www.tnlea.com/QuickLinks/LEA-2025/Previous%20Year%20(2024)%20cutoff%20-%20LEA%202025.pdf','ingested_needs_spot_check','PDF extracted; parser output is a preliminary subset, not certified complete.'),('TNLEA 2025 previous-year cutoff','2025','https://www.tnlea.com/QuickLinks/LEA-2026/Previous_Year_cutoff2025.pdf','ingested_needs_spot_check','PDF extracted; parser output is a preliminary subset, not certified complete.'),('TNLEA 2023 cutoff','2023','https://www.tnlea.com/supplementary_2024/links/Previous_Year_Cut-Off.pdf','not_ingested','Prior local copy was invalid; re-download and validate before use.'),('TNLEA 2022 cutoff','2022','https://www.tnlea.com/','unresolved','No validated official cutoff PDF in current evidence.'),('TNLEA 2026 final cutoff','2026','https://www.tnlea.com/','unresolved','Final cutoff not verified; vacancy list is not a final cutoff.'),('TNLEA 2025 college directory','2025','https://www.tnlea.com/QuickLinks/LEA-2025/listofcollegs.pdf','ingested','Official college code directory; duplicate source codes preserved as a quality flag.')]
for s in sources: db.execute('INSERT INTO data_sources(title,year,url,status,notes) VALUES(?,?,?,?,?)',s)
db.commit()
print('colleges',db.execute('select count(*) from colleges').fetchone()[0], 'cutoffs',db.execute('select count(*) from cutoff_observations').fetchone()[0], 'sources',db.execute('select count(*) from data_sources').fetchone()[0])
print('years',db.execute('select admission_year,count(*) from cutoff_observations group by admission_year').fetchall())
print('distinct college codes',db.execute('select count(distinct college_code) from cutoff_observations').fetchone()[0])
print('duplicate keys',db.execute('select count(*) from (select admission_year,college_code,branch_code,category,count(*) c from cutoff_observations group by 1,2,3,4 having c>1)').fetchone()[0])
