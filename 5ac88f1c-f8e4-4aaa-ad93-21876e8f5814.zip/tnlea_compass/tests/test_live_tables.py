import sqlite3, unittest
from pathlib import Path
DB=Path(__file__).resolve().parents[1]/'tnlea.db'
class LiveDataTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.db=sqlite3.connect(DB)
 @classmethod
 def tearDownClass(cls): cls.db.close()
 def test_live_source_check_schema_exists(self):
  self.assertIsNotNone(self.db.execute("select name from sqlite_master where type='table' and name='live_source_checks'").fetchone())
 def test_vacancy_snapshot_schema_exists(self):
  self.assertIsNotNone(self.db.execute("select name from sqlite_master where type='table' and name='live_vacancy_snapshots'").fetchone())
 def test_saved_snapshot_has_hash_and_provenance(self):
  n=self.db.execute("select count(*) from live_vacancy_snapshots where length(payload_sha256)=64 and source_url like 'https://www.tnlea.com/%' and retrieved_at is not null").fetchone()[0]
  self.assertGreaterEqual(n,1)
 def test_snapshot_counts_reconcile(self):
  rows=self.db.execute('select payload_json from live_vacancy_snapshots').fetchall()
  import json
  for (payload,) in rows:
   for r in json.loads(payload):
    self.assertEqual(r['COUNTER'],sum(r[k] for k in ('OC','BC','BCM','MBC','SC','SCA','ST')))
if __name__=='__main__': unittest.main()
