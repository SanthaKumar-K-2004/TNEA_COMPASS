import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class FreeRuntimeTests(unittest.TestCase):
 def test_no_third_party_runtime_script_cdn(self):
  html=(ROOT/'app/index.html').read_text()
  self.assertIn('/vendor/chart.umd.min.js',html)
  self.assertNotIn('cdn.jsdelivr.net',html)
 def test_chart_bundle_and_license_are_present(self):
  self.assertGreater((ROOT/'app/vendor/chart.umd.min.js').stat().st_size,100_000)
  self.assertIn('MIT',(ROOT/'app/vendor/CHARTJS-LICENSE.txt').read_text())
 def test_runtime_requirements_are_standard_library_only(self):
  req=(ROOT/'requirements.txt').read_text()
  self.assertNotRegex(req,r'(?m)^\\s*[A-Za-z][A-Za-z0-9_-]*[<=>~]')
 def test_local_only_default_bind(self):
  server=(ROOT/'server.py').read_text()
  self.assertIn("host=os.getenv('HOST','127.0.0.1')",server)
 def test_no_secrets_in_runtime_source(self):
  for name in ('server.py','app/index.html'):
   s=(ROOT/name).read_text().lower()
   self.assertNotIn('sk-proj-',s)
   self.assertNotIn('AIzaSy',s)
if __name__=='__main__': unittest.main()
