import math, sqlite3, unittest
from pathlib import Path
DB=Path(__file__).resolve().parents[1]/'tnlea.db'
class DataIntegrityTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls): cls.db=sqlite3.connect(DB)
 @classmethod
 def tearDownClass(cls): cls.db.close()
 def test_database_integrity(self): self.assertEqual(self.db.execute('pragma integrity_check').fetchone()[0],'ok')
 def test_unique_cutoff_grain(self):
  n=self.db.execute('select count(*) from (select admission_year,college_code,branch_code,category,count(*) n from cutoff_observations group by 1,2,3,4 having n>1)').fetchone()[0]
  self.assertEqual(n,0)
 def test_cutoff_values_in_range(self):
  n=self.db.execute('select count(*) from cutoff_observations where min_mark not between 0 and 100 or max_mark not between 0 and 100 or min_mark>max_mark').fetchone()[0]
  self.assertEqual(n,0)
 def test_provenance_present(self):
  n=self.db.execute('select count(*) from cutoff_observations where source_url is null or source_page is null or source_line is null or source_sha256 is null').fetchone()[0]
  self.assertEqual(n,0)
 def test_only_real_years_loaded(self):
  years=[r[0] for r in self.db.execute('select distinct admission_year from cutoff_observations order by 1')]
  self.assertEqual(years,[2024,2025])
 def test_no_unverified_financial_or_placement_records(self):
  for table in ('college_fees','placement_outcomes','institutional_rankings','scholarships','branch_seats'):
   self.assertEqual(self.db.execute(f'select count(*) from {table}').fetchone()[0],0,table)
if __name__=='__main__': unittest.main()
