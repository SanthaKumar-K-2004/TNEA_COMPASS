# TNLEA Compass — v1.4.1 free-runtime verified build

## Free runtime and deployment notes
- Backend: Python 3 standard library only (`http.server`, `sqlite3`, `urllib`); no paid API, API key, subscription, database service or Python package is required.
- Database: local SQLite file (`tnlea.db`).
- Charts: Chart.js 4.4.7 is bundled locally under `app/vendor/` with its MIT license; the app does not require a third-party JavaScript CDN to render charts.
- Live official vacancy/source checks require an internet connection to TNLEA. They are direct source lookups, not a paid API.
- Default bind is `127.0.0.1` for safer local-only use. Set `HOST=0.0.0.0` only when intentionally sharing on a trusted LAN; do not expose this development server directly to the public internet.
- Hosting may be free on a suitable provider, but provider free tiers and limits can change. Local use does not require hosting or payment.

## v1.4 live-data features
- Live college-wise 2026 vacancy snapshot fetched on demand from the public TNLEA portal endpoint used by its official Vacancy Position After Round 1 page.
- Every live response is validated (college code, branch rows, seven category counts and reconciled COUNTER), timestamped in UTC, SHA-256 fingerprinted and saved as a raw snapshot.
- Snapshot history endpoint allows repeat fetch comparison and reports changed category counts; first fetch is clearly identified.
- Live source monitor checks five official TNLEA URLs for reachability, HTTP status, Last-Modified, ETag, content type and content length; metadata changes are flagged.
- Live data is not merged into historical cutoff tables or described as current open seats. The source is specifically the published post-Round-1 snapshot.

## Included
- v1.2 PDF extraction QA pipeline with idempotent rebuild, SHA-256 source hashes, page/line provenance and an extraction audit CSV.
- Rebuilt 2024/2025 cutoff dataset: 30,716 category observations from 4,388 college-branch rows (2,140 + 2,248), with structural QA pass.
- Evidence-quality API (`/api/quality`) and dashboard panel.

## Included
- API input validation, finite mark/range checks, supported-year/category checks, and explicit HTTP 400 errors for invalid requests.
- Paginated college and cutoff APIs and dashboard navigation (no silent 1,000-row truncation).
- Recommendation results ordered by nearest historical MIN mark, with the old misleading `Historically above minimum` / arbitrary 5-mark band removed.
- Comparison endpoint now includes source-linked historical cutoffs and flags ambiguous college codes.
- Six automated database integrity regression tests.
- Bilingual (Tamil/English) responsive dashboard.
- Python standard-library HTTP API and SQLite database.
- 426 unique official TNLEA 2025 college-code/name directory records, derived from 430 source rows. Duplicate code flags retained.
- Official 2024/2025 MAX/MIN cutoff tables structurally parsed from source PDFs with page/line/SHA-256 provenance; manual visual spot-checking is still pending.
- Cutoff explorer, college directory, historical chart and source register.
- Forecast endpoint deliberately refuses to publish a forecast with fewer than three validated comparable years.

## Run
Python 3.10+; no third-party Python packages required.

```bash
python3 verify_cutoff_pdfs.py
python3 server.py
```
Open http://localhost:8000

Run regression checks with `python3 -m unittest discover -s tests -v`.

## Live endpoints
- `POST /api/live/vacancy` JSON body: `{"collegeCode":"2602"}` — fetch and persist official post-Round-1 vacancy snapshot.
- `GET /api/live/vacancy-history?college=2602` — list prior saved snapshots and hashes.
- `GET /api/live/sources` — latest saved official source checks.
- `POST /api/live/refresh-sources` JSON body `{}` — make new HEAD checks against official TNLEA portal, candidate instructions, vacancy page, cutoff PDF and college directory.

The server performs live network requests only when these endpoints are called. No background polling is configured. For a deployed instance, schedule source checks responsibly (for example, daily) and avoid repeatedly hammering the official portal. The live vacancy endpoint is queried per college code, not bulk-harvested.


## Data limitations — read before use
- Only 2024 and 2025 historical cutoff data are ingested. The 2026 live feature is a separate post-Round-1 vacancy snapshot, not a final cutoff or live allotment stream.
- The parser detects 2,140 (2024) and 2,248 (2025) branch rows and passes structural checks for the expected 14 category cells per row, page/line provenance, numeric range, duplicate grain, and MAX/MIN ordering. This is not manual visual verification of every source cell; status remains spot-check pending. See `DATA_VERIFICATION_REPORT.md`.
- 2022 is unresolved. The 2023 official source requires recovery and validation. Final 2026 cutoff is not verified.
- Published fields are cutoff marks (MAX/MIN), not opening/closing ranks.
- No statewide fees or placements are fabricated; these modules are not populated yet.
- Forecasting is intentionally disabled pending five-year data, clean validation, and chronological backtesting.

## Next engineering steps
1. Complete human visual spot checks against source PDF page images and record reviewer/date evidence.
2. Recover validated 2022/2023 sources and import any new official 2026 final cutoff only when published.
3. Add annual branch/seat data, fees, placement cohorts and ranking records with provenance.
4. Move from SQLite to managed PostgreSQL when multi-user hosting is required.
5. Implement and backtest forecasting models; keep a baseline and uncertainty intervals.
